package app.quests.timeline;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.IntentSender;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.google.android.gms.auth.api.identity.AuthorizationRequest;
import com.google.android.gms.auth.api.identity.AuthorizationResult;
import com.google.android.gms.auth.api.identity.Identity;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.Scope;

import org.json.JSONObject;

import java.util.Collections;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private static final int FILE_CHOOSER_REQUEST = 4107;
    private static final int GOOGLE_AUTH_REQUEST = 4108;
    private static final String CALENDAR_SCOPE = "https://www.googleapis.com/auth/calendar.events";

    /** Exposed to index.html as window.QuestsNative. */
    public class QuestsBridge {
        @JavascriptInterface
        public void requestGoogleToken() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    startGoogleAuthorization();
                }
            });
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(9,11,16));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(9,11,16));
        webView = new WebView(this);
        webView.setBackgroundColor(android.graphics.Color.rgb(9,11,16));
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        webView.addJavascriptInterface(new QuestsBridge(), "QuestsNative");
        // Only the bundled app page may live in the WebView (it holds the bridge).
        // Any web link is opened in the phone's browser instead.
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handleUrl(request.getUrl());
            }

            @Override
            @SuppressWarnings("deprecation")
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return handleUrl(Uri.parse(url));
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                    FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent intent = params.createIntent();
                try {
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                    return true;
                } catch (Exception e) {
                    fileCallback = null;
                    return false;
                }
            }
        });
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private boolean handleUrl(Uri url) {
        String scheme = url.getScheme();
        if ("file".equals(scheme)) return false; // stay inside the app
        if ("http".equals(scheme) || "https".equals(scheme)) {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, url));
            } catch (Exception ignored) {
            }
        }
        return true; // never load external pages inside the WebView
    }

    // ---- Native Google authorization (Calendar) ----

    private void startGoogleAuthorization() {
        AuthorizationRequest authRequest = AuthorizationRequest.builder()
                .setRequestedScopes(Collections.singletonList(new Scope(CALENDAR_SCOPE)))
                .build();
        Identity.getAuthorizationClient(this)
                .authorize(authRequest)
                .addOnSuccessListener(result -> {
                    if (result.hasResolution()) {
                        PendingIntent pendingIntent = result.getPendingIntent();
                        if (pendingIntent == null) {
                            sendAuthResult(null, "Google consent screen is unavailable");
                            return;
                        }
                        try {
                            startIntentSenderForResult(pendingIntent.getIntentSender(),
                                    GOOGLE_AUTH_REQUEST, null, 0, 0, 0);
                        } catch (IntentSender.SendIntentException e) {
                            sendAuthResult(null, "Could not open Google consent screen");
                        }
                    } else {
                        sendAuthResult(result.getAccessToken(), null);
                    }
                })
                .addOnFailureListener(e -> sendAuthResult(null, describeError(e)));
    }

    private String describeError(Exception e) {
        if (e instanceof ApiException) {
            int code = ((ApiException) e).getStatusCode();
            if (code == 10) {
                return "Google error 10 (DEVELOPER_ERROR): the Android OAuth client in Google Cloud "
                        + "does not match this app's package name / SHA-1";
            }
            return "Google error " + code + ": " + e.getMessage();
        }
        return e.getMessage() != null ? e.getMessage() : "Google authorization failed";
    }

    /** Sends the result back to index.html: window.__questsAuth(token, error). */
    private void sendAuthResult(String token, String error) {
        if (webView == null) return;
        String js = "window.__questsAuth&&window.__questsAuth("
                + JSONObject.quote(token == null ? "" : token) + ","
                + JSONObject.quote(error == null ? "" : error) + ")";
        webView.evaluateJavascript(js, null);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST && fileCallback != null) {
            Uri[] results = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            fileCallback.onReceiveValue(results);
            fileCallback = null;
        } else if (requestCode == GOOGLE_AUTH_REQUEST) {
            if (resultCode != RESULT_OK || data == null) {
                sendAuthResult(null, "Google sign-in was cancelled");
                return;
            }
            try {
                AuthorizationResult result =
                        Identity.getAuthorizationClient(this).getAuthorizationResultFromIntent(data);
                sendAuthResult(result.getAccessToken(), null);
            } catch (ApiException e) {
                sendAuthResult(null, describeError(e));
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
