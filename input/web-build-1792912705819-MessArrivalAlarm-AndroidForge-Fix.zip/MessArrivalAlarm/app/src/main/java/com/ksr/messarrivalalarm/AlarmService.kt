package com.ksr.messarrivalalarm

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.tts.TextToSpeech
import java.util.Locale

class AlarmService : Service(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var pendingText: String? = null
    private var ready = false
    private val handler = Handler(Looper.getMainLooper())
    private val autoStop = Runnable { stopAlarm() }
    private val repeatAnnouncement = object : Runnable {
        override fun run() {
            val text = pendingText
            if (ready && text != null) {
                tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "mess_arrival_announcement")
                handler.postDelayed(this, 8_000L)
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        createChannel()
        tts = TextToSpeech(this, this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopAlarm()
            return START_NOT_STICKY
        }
        if (intent?.action == ACTION_START) {
            pendingText = intent.getStringExtra(EXTRA_ANNOUNCEMENT)
                ?: "Khana aane wala hai! Please ready raho aur patience rakho. Thank you!"
            startForeground(NOTIFICATION_ID, buildNotification())
            handler.removeCallbacks(autoStop)
            handler.removeCallbacks(repeatAnnouncement)
            handler.postDelayed(autoStop, 60_000L)
            speakIfReady()
            handler.postDelayed(repeatAnnouncement, 8_000L)
        }
        return START_NOT_STICKY
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            ready = true
            // Hinglish usually sounds most natural with the device's English/Indian voice.
            val result = tts?.setLanguage(Locale("en", "IN"))
            if (result == TextToSpeech.LANG_MISSING_DATA ||
                result == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts?.setLanguage(Locale.US)
            }
            speakIfReady()
        }
    }

    private fun speakIfReady() {
        val text = pendingText ?: return
        if (!ready) return
        tts?.stop()
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "mess_arrival_announcement")
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "Food arrival alarm", NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Shows when the mess food arrival announcement is playing"
                setSound(null, null)
                enableVibration(false)
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val stopIntent = Intent(this, AlarmService::class.java).apply { action = ACTION_STOP }
        val stopPending = PendingIntent.getService(
            this, 1, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or
                (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        )
        val openIntent = PendingIntent.getActivity(
            this, 2, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or
                (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        )
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            Notification.Builder(this, CHANNEL_ID) else Notification.Builder(this)
        return builder
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("Food is arriving!")
            .setContentText("Khana aane wala hai — tap STOP to silence.")
            .setContentIntent(openIntent)
            .setCategory(Notification.CATEGORY_ALARM)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_media_pause, "STOP ALARM", stopPending)
            .build()
    }

    private fun stopAlarm() {
        handler.removeCallbacks(autoStop)
        handler.removeCallbacks(repeatAnnouncement)
        tts?.stop()
        pendingText = null
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) stopForeground(STOP_FOREGROUND_REMOVE)
        else @Suppress("DEPRECATION") stopForeground(true)
        stopSelf()
    }

    override fun onDestroy() {
        handler.removeCallbacks(autoStop)
        handler.removeCallbacks(repeatAnnouncement)
        tts?.stop()
        tts?.shutdown()
        tts = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_START = "com.ksr.messarrivalalarm.START"
        const val ACTION_STOP = "com.ksr.messarrivalalarm.STOP"
        const val EXTRA_ANNOUNCEMENT = "announcement"
        private const val CHANNEL_ID = "food_arrival_alarm"
        private const val NOTIFICATION_ID = 4107
    }
}
