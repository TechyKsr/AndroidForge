package com.karan.idlesaver

import android.content.Context

/**
 * Tiny wrapper around SharedPreferences + the timing constants of the app.
 * Video URIs are stored as one string, one URI per line.
 */
object Prefs {

    /** No interaction for this long -> start the saver. */
    const val IDLE_MS = 60_000L

    /** Saver plays at least this long before the screen is locked. Shorter videos loop. */
    const val MIN_PLAY_MS = 10_000L

    /** Safety cap: a long video is cut off after this and the screen is locked. */
    const val MAX_PLAY_MS = 120_000L

    private const val FILE = "idlesaver"
    private const val KEY_VIDEOS = "videos"
    private const val KEY_ENABLED = "enabled"
    private const val KEY_STRICT = "strict_home_only"
    private const val KEY_SOUND = "sound"

    private fun sp(c: Context) =
        c.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun getVideos(c: Context): List<String> =
        (sp(c).getString(KEY_VIDEOS, "") ?: "").split('\n').filter { it.isNotBlank() }

    fun addVideos(c: Context, uris: List<String>) {
        val all = (getVideos(c) + uris).distinct()
        sp(c).edit().putString(KEY_VIDEOS, all.joinToString("\n")).apply()
    }

    fun clearVideos(c: Context) {
        sp(c).edit().remove(KEY_VIDEOS).apply()
    }

    fun isEnabled(c: Context) = sp(c).getBoolean(KEY_ENABLED, true)
    fun setEnabled(c: Context, v: Boolean) = sp(c).edit().putBoolean(KEY_ENABLED, v).apply()

    /** true = saver runs only when the home launcher is the foreground app. */
    fun isStrictHomeOnly(c: Context) = sp(c).getBoolean(KEY_STRICT, false)
    fun setStrictHomeOnly(c: Context, v: Boolean) = sp(c).edit().putBoolean(KEY_STRICT, v).apply()

    fun isSoundOn(c: Context) = sp(c).getBoolean(KEY_SOUND, false)
    fun setSoundOn(c: Context, v: Boolean) = sp(c).edit().putBoolean(KEY_SOUND, v).apply()
}
