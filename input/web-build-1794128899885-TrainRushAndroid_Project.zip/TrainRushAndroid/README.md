# Train Rush — Android project

This project wraps the supplied Train Rush HTML game in a full-screen Android WebView app.

## Build an APK
1. Install Android Studio (current stable) with Android SDK Platform 35 and Build Tools.
2. Open this `TrainRushAndroid` folder in Android Studio.
3. Allow Gradle sync to finish.
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Android Studio creates the APK under `app/build/outputs/apk/debug/`.
6. Transfer the APK to your Android phone and install it. For a release APK, use **Build → Generate Signed Bundle / APK**.

## Notes
- The original game is preserved in `app/src/main/assets/index.html`.
- The HTML loads Three.js r128 from cdnjs and the Rajdhani font from Google Fonts, so the first launch/game rendering needs an internet connection. The game itself is stored inside the app.
- Coins, level progress and high score use browser local storage in the WebView.
- Package ID: `com.ksr.trainrush`.
