package com.ksr.messarrivalalarm

import android.Manifest
import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private lateinit var triggerInput: EditText
    private lateinit var announcementInput: EditText
    private lateinit var durationSpinner: Spinner
    private lateinit var customDurationInput: EditText
    private lateinit var intervalSpinner: Spinner
    private lateinit var audioModeSpinner: Spinner
    private lateinit var iconSpinner: Spinner
    private lateinit var audioStatus: TextView
    private var selectedAudioUri: Uri? = null

    private val durationLabels = listOf("30 seconds", "1 minute", "2 minutes", "5 minutes", "Custom (seconds)")
    private val durationValues = listOf(30, 60, 120, 300, -1)
    private val intervalValues = listOf(5, 8, 10, 15, 20)
    private val intervalLabels = intervalValues.map { "Every $it seconds" }
    private val audioModes = listOf("Speak announcement (text-to-speech)", "Play selected audio file")
    private val iconLabels = listOf("Food icon", "Alarm clock icon", "Bell icon")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = AlarmPrefs.prefs(this)
        selectedAudioUri = prefs.getString(AlarmPrefs.KEY_AUDIO_URI, null)?.let { Uri.parse(it) }

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(24), dp(22), dp(24))
        }
        content.addView(TextView(this).apply {
            text = "Mess Announcer"
            textSize = 27f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(8))
        }, matchWidth())
        content.addView(TextView(this).apply {
            text = "Choose the exact WhatsApp notification text that should trigger the alarm. You can change Keshavtiffin to another word or phrase anytime."
            textSize = 14f
        }, matchWidth())

        addLabel(content, "WhatsApp trigger text (exact match)")
        triggerInput = EditText(this).apply {
            setText(prefs.getString(AlarmPrefs.KEY_TRIGGER_TEXT, DEFAULT_TRIGGER_TEXT))
            hint = "For example: Keshavtiffin"
            singleLine = true
        }
        content.addView(triggerInput, matchWidth())

        addLabel(content, "Announcement text")
        announcementInput = EditText(this).apply {
            setText(prefs.getString(AlarmPrefs.KEY_ANNOUNCEMENT, DEFAULT_ANNOUNCEMENT))
            hint = "Type the words the app should speak"
            minLines = 2
            maxLines = 4
            gravity = Gravity.TOP
        }
        content.addView(announcementInput, matchWidth())

        addLabel(content, "Alarm sound")
        audioModeSpinner = spinner(audioModes).also { content.addView(it, matchWidth()) }
        audioModeSpinner.setSelection(if (prefs.getString(AlarmPrefs.KEY_AUDIO_MODE, AlarmPrefs.MODE_TTS) == AlarmPrefs.MODE_AUDIO) 1 else 0)
        content.addView(button("Choose audio file (MP3, WAV, etc.)") { chooseAudio() }, matchWidth())
        audioStatus = TextView(this).apply { textSize = 12f }
        content.addView(audioStatus, matchWidth())
        updateAudioStatus()

        addLabel(content, "How long should the alarm run?")
        durationSpinner = spinner(durationLabels).also { content.addView(it, matchWidth()) }
        val savedDuration = prefs.getInt(AlarmPrefs.KEY_DURATION, 60)
        val durationIndex = durationValues.indexOf(savedDuration).let { if (it < 0) 4 else it }
        durationSpinner.setSelection(durationIndex)
        customDurationInput = EditText(this).apply {
            hint = "Custom duration in seconds (10–600)"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setText(if (durationIndex == 4) savedDuration.toString() else "120")
        }
        content.addView(customDurationInput, matchWidth())
        durationSpinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                customDurationInput.visibility = if (position == 4) android.view.View.VISIBLE else android.view.View.GONE
            }
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
        }

        addLabel(content, "Repeat interval")
        intervalSpinner = spinner(intervalLabels).also { content.addView(it, matchWidth()) }
        val savedInterval = prefs.getInt(AlarmPrefs.KEY_INTERVAL, 8)
        intervalSpinner.setSelection(intervalValues.indexOf(savedInterval).takeIf { it >= 0 } ?: 1)

        addLabel(content, "App icon")
        iconSpinner = spinner(iconLabels).also { content.addView(it, matchWidth()) }
        iconSpinner.setSelection(prefs.getInt(AlarmPrefs.KEY_ICON, 0).coerceIn(0, 2))

        content.addView(button("SAVE SETTINGS") { saveSettings() }, matchWidth())
        content.addView(button("1. Allow notification permission (Android 13+)") {
            if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 11)
            } else openNotificationAccess()
        }, matchWidth())
        content.addView(button("2. Enable WhatsApp notification access") { openNotificationAccess() }, matchWidth())
        content.addView(button("3. Open app notification settings") {
            startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName))
        }, matchWidth())
        content.addView(button("STOP ALARM") { stopService(Intent(this, AlarmService::class.java)) }, matchWidth())
        content.addView(TextView(this).apply {
            text = "Setup tip: WhatsApp group notifications must be enabled. If you select an audio file, grant access using the file picker. Some launchers take a little time to refresh the app icon after saving."
            textSize = 12f
        }, matchWidth())

        setContentView(ScrollView(this).apply { addView(content) })
    }

    private fun addLabel(parent: LinearLayout, label: String) {
        parent.addView(TextView(this).apply {
            text = label
            textSize = 16f
            setPadding(0, dp(10), 0, dp(4))
        }, matchWidth())
    }

    private fun spinner(items: List<String>) = Spinner(this).apply {
        adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, items)
    }

    private fun matchWidth() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
        bottomMargin = dp(8)
    }

    private fun button(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setOnClickListener { action() }
    }

    private fun chooseAudio() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "audio/*"
        }
        startActivityForResult(intent, REQUEST_AUDIO)
    }

    @Deprecated("Uses Activity result API compatible with older AndroidForge templates")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_AUDIO && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) { }
            selectedAudioUri = uri
            updateAudioStatus()
            audioModeSpinner.setSelection(1)
        }
    }

    private fun updateAudioStatus() {
        audioStatus.text = selectedAudioUri?.let { "Selected file: ${it.lastPathSegment ?: it}" } ?: "No custom audio selected; text-to-speech is available."
    }

    private fun saveSettings() {
        val durationPosition = durationSpinner.selectedItemPosition
        val duration = if (durationPosition == 4) {
            val entered = customDurationInput.text.toString().toIntOrNull()
            if (entered == null || entered !in 10..600) {
                customDurationInput.error = "Enter 10 to 600 seconds"
                Toast.makeText(this, "Custom duration must be between 10 and 600 seconds", Toast.LENGTH_LONG).show()
                return
            }
            entered
        } else durationValues[durationPosition]

        val trigger = triggerInput.text.toString().trim()
        if (trigger.isEmpty()) {
            triggerInput.error = "Enter the WhatsApp text to detect"
            Toast.makeText(this, "Trigger text cannot be empty", Toast.LENGTH_LONG).show()
            return
        }

        val mode = if (audioModeSpinner.selectedItemPosition == 1) AlarmPrefs.MODE_AUDIO else AlarmPrefs.MODE_TTS
        if (mode == AlarmPrefs.MODE_AUDIO && selectedAudioUri == null) {
            Toast.makeText(this, "Choose an audio file first, or select text-to-speech", Toast.LENGTH_LONG).show()
            return
        }
        val iconChoice = iconSpinner.selectedItemPosition.coerceIn(0, 2)
        AlarmPrefs.prefs(this).edit()
            .putString(AlarmPrefs.KEY_TRIGGER_TEXT, trigger)
            .putString(AlarmPrefs.KEY_ANNOUNCEMENT, announcementInput.text.toString().trim().ifEmpty { DEFAULT_ANNOUNCEMENT })
            .putInt(AlarmPrefs.KEY_DURATION, duration)
            .putInt(AlarmPrefs.KEY_INTERVAL, intervalValues[intervalSpinner.selectedItemPosition])
            .putString(AlarmPrefs.KEY_AUDIO_URI, selectedAudioUri?.toString())
            .putString(AlarmPrefs.KEY_AUDIO_MODE, mode)
            .putInt(AlarmPrefs.KEY_ICON, iconChoice)
            .apply()
        applyLauncherIcon(iconChoice)
        Toast.makeText(this, "Settings saved", Toast.LENGTH_SHORT).show()
    }

    private fun applyLauncherIcon(choice: Int) {
        val aliases = listOf(".LauncherFood", ".LauncherAlarm", ".LauncherBell")
        aliases.forEachIndexed { index, alias ->
            val state = if (index == choice) PackageManager.COMPONENT_ENABLED_STATE_ENABLED else PackageManager.COMPONENT_ENABLED_STATE_DISABLED
            packageManager.setComponentEnabledSetting(ComponentName(packageName, packageName + alias), state, PackageManager.DONT_KILL_APP)
        }
    }

    private fun openNotificationAccess() {
        startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
    }

    companion object {
        private const val REQUEST_AUDIO = 77
        private const val DEFAULT_TRIGGER_TEXT = "Keshavtiffin"
        private const val DEFAULT_ANNOUNCEMENT = "Khana aane wala hai! Please ready raho aur patience rakho. Thank you!"
    }
}
