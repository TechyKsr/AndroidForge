package com.ksr.messarrivalalarm

import android.app.Notification
import android.content.Intent
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.os.Build

class MessNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        // Only watch WhatsApp notifications.
        val pkg = sbn.packageName
        if (pkg != "com.whatsapp" && pkg != "com.whatsapp.w4b") return

        val extras = sbn.notification.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.trim().orEmpty()
        val bigText = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()?.trim().orEmpty()

        // Exact match: only a notification text that equals Keshavtiffin triggers.
        // WhatsApp may place the sender/group name in the title and message in text.
        val candidates = listOf(text, bigText)
        if (candidates.any { it.equals("Keshavtiffin", ignoreCase = true) }) {
            val intent = Intent(this, AlarmService::class.java).apply {
                action = AlarmService.ACTION_START
                putExtra(AlarmService.EXTRA_ANNOUNCEMENT,
                    "Khana aane wala hai! Please ready raho aur patience rakho. Thank you!")
            }
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent)
                else startService(intent)
            } catch (_: Exception) {
                // Android may block background service start in some states.
                // User can reopen the app and verify notification/battery settings.
            }
        }
    }
}
