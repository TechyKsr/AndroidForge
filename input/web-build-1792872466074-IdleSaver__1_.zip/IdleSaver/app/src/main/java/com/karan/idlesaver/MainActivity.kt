package com.karan.idlesaver

import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts

/** Settings screen: enable service, pick videos, options, test button. */
class MainActivity : ComponentActivity() {

    private lateinit var tvService: TextView
    private lateinit var tvVideos: TextView
    private lateinit var tvWarning: TextView
    private lateinit var swEnabled: Switch
    private lateinit var swStrict: Switch
    private lateinit var swSound: Switch

    // System file picker. No storage permission needed; we keep access with a persistable grant.
    private val pickVideos =
        registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
            if (uris.isEmpty()) return@registerForActivityResult
            uris.forEach {
                runCatching {
                    contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
            }
            Prefs.addVideos(this, uris.map { it.toString() })
            refresh()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvService = findViewById(R.id.tvService)
        tvVideos = findViewById(R.id.tvVideos)
        tvWarning = findViewById(R.id.tvWarning)
        swEnabled = findViewById(R.id.swEnabled)
        swStrict = findViewById(R.id.swStrict)
        swSound = findViewById(R.id.swSound)

        findViewById<Button>(R.id.btnAccessibility).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        findViewById<Button>(R.id.btnPick).setOnClickListener {
            pickVideos.launch(arrayOf("video/*"))
        }
        findViewById<Button>(R.id.btnClear).setOnClickListener {
            Prefs.getVideos(this).forEach {
                runCatching {
                    contentResolver.releasePersistableUriPermission(
                        Uri.parse(it), Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                }
            }
            Prefs.clearVideos(this)
            refresh()
        }
        findViewById<Button>(R.id.btnTest).setOnClickListener {
            val service = IdleAccessibilityService.instance
            when {
                service == null -> toast("Turn the service on in Accessibility settings first")
                Prefs.getVideos(this).isEmpty() -> toast("Pick at least one video first")
                else -> service.startSaverForTest()
            }
        }

        swEnabled.setOnCheckedChangeListener { _, on -> Prefs.setEnabled(this, on) }
        swStrict.setOnCheckedChangeListener { _, on -> Prefs.setStrictHomeOnly(this, on) }
        swSound.setOnCheckedChangeListener { _, on -> Prefs.setSoundOn(this, on) }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        tvService.text = if (isServiceEnabled()) {
            "Service: ON"
        } else {
            "Service: OFF. Open Accessibility settings, find \"Idle Saver\" and switch it on."
        }

        val videos = Prefs.getVideos(this)
        tvVideos.text = if (videos.isEmpty()) {
            "No videos selected yet."
        } else {
            val names = videos.take(3).joinToString(", ") { displayName(Uri.parse(it)) }
            "${videos.size} video(s): $names" + if (videos.size > 3) " ..." else ""
        }

        swEnabled.isChecked = Prefs.isEnabled(this)
        swStrict.isChecked = Prefs.isStrictHomeOnly(this)
        swSound.isChecked = Prefs.isSoundOn(this)

        // The system's own display timeout must be LONGER than idle time + minimum play time,
        // otherwise Android turns the screen off before our saver gets its turn.
        val timeout = Settings.System.getInt(contentResolver, Settings.System.SCREEN_OFF_TIMEOUT, 0)
        val needed = Prefs.IDLE_MS + Prefs.MIN_PLAY_MS + 5_000L
        if (timeout in 1 until needed) {
            tvWarning.visibility = View.VISIBLE
            tvWarning.text = "Warning: your screen timeout is ${timeout / 1000} s. " +
                "Set it to 2 minutes or more (Settings > Display > Screen timeout), " +
                "otherwise the system turns the screen off before the saver can play."
        } else {
            tvWarning.visibility = View.GONE
        }
    }

    private fun isServiceEnabled(): Boolean {
        val me = ComponentName(this, IdleAccessibilityService::class.java)
        val enabled = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabled.split(':').any {
            it.equals(me.flattenToString(), ignoreCase = true) ||
                it.equals(me.flattenToShortString(), ignoreCase = true)
        }
    }

    private fun displayName(uri: Uri): String = runCatching {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
    }.getOrNull() ?: uri.lastPathSegment ?: "video"

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
}
