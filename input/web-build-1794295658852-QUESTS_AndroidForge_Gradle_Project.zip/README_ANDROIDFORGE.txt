QUESTS — Android Gradle project

This package fixes the previous ZIP structure issue: it is now a real Android Gradle project.
The Android project root is this folder; settings.gradle and build.gradle are at the ZIP root.

Included:
- Android Gradle Plugin project (AGP 8.7.3), compileSdk 35, Java 17
- Native Android launcher icon generated from the exact original image uploaded by you
- WebView app shell loading the QUESTS timeline from app/src/main/assets/index.html
- File picker support for task images and background image uploads
- Internet permission for Google Calendar API requests

AndroidForge:
1. Upload this ZIP as an Android/Gradle project (not as a single HTML/web project).
2. If asked for project root, choose the extracted folder containing settings.gradle.
3. Build debug first. If the service requires a different AGP/Gradle/SDK version, share its exact error log.
4. The installed app label is QUESTS and launcher icon is app/src/main/res/mipmap-*.

Google Calendar:
The in-app OAuth flow still needs your Google OAuth Client ID and Google Cloud Calendar API configuration.
Google's OAuth sign-in inside generic file:// WebViews may be blocked by Google. For production use, host the web app on HTTPS with an authorized origin or implement native Google Sign-In. Calendar sync is not background continuous sync.

The Android app source is unsigned. AndroidForge should create/sign the APK during its build flow.
