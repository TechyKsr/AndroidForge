package com.ksr.messarrivalalarm

import android.content.Context

object AlarmPrefs {
    private const val FILE = "mess_arrival_settings"
    const val KEY_TRIGGER_TEXT = "trigger_text"
    const val KEY_ANNOUNCEMENT = "announcement"
    const val KEY_DURATION = "duration_seconds"
    const val KEY_INTERVAL = "interval_seconds"
    const val KEY_AUDIO_URI = "audio_uri"
    const val KEY_AUDIO_MODE = "audio_mode"
    const val KEY_ICON = "icon_choice"
    const val MODE_TTS = "tts"
    const val MODE_AUDIO = "audio"

    fun prefs(context: Context) = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
}
