# Mess Arrival Alarm (Android)

A small native Android starter project. It watches WhatsApp notification text and speaks a Hinglish food-arrival reminder when the message body is exactly `Keshavtiffin`. The announcement is spoken immediately and repeated about every 8 seconds; the foreground notification offers STOP ALARM, and the service automatically stops after 60 seconds.

## Important limitations
- This starter listens to notifications; it does not read WhatsApp chat history.
- WhatsApp must show the group message text in a notification. If the group is muted, notifications are hidden, or Android hides message content, detection will not work.
- Exact matching currently checks the notification's message text / big text against `Keshavtiffin`, case-insensitively. It does not trigger if WhatsApp combines the name with other text (for example `Keshavtiffin, be ready`) or only exposes a summary such as `2 new messages`.
- Android background restrictions, force-stop, battery saver, or OEM settings can delay/block service starts. Test on the actual phone.
- Text-to-speech depends on the Android voice installed on the phone. The voice repeats the announcement about every 8 seconds; this is a voice-only alarm rather than a siren. You can tap STOP ALARM in the persistent notification to silence it; it ends automatically after 60 seconds.
- Granting notification access is powerful: Android lets this app inspect notification content. This starter only checks WhatsApp notification text locally and does not upload it anywhere. Only install code you trust.

## Build the APK with Android Studio
1. Install the latest stable Android Studio from the official Android developer website.
2. Extract this ZIP.
3. In Android Studio choose **Open**, then select the extracted `MessArrivalAlarm` folder (the folder containing `settings.gradle.kts`).
4. Allow Gradle sync/downloads. Install Android SDK Platform 35 if prompted.
5. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. When complete, click **locate** in the build notification. The debug APK is usually at:
   `app/build/outputs/apk/debug/app-debug.apk`
7. Transfer that APK to your Android phone and install it. For a debug APK, Android may ask you to allow installs from that file manager/browser. Only do this for code you have reviewed and built yourself.

## First-run setup on phone
1. Open Mess Arrival Alarm.
2. Grant notification permission if Android asks.
3. Tap **Enable WhatsApp notification access** and enable Mess Arrival Alarm in Android settings.
4. Ensure WhatsApp notifications and the mess group notifications are enabled and show message content on the lock screen/notification shade.
5. In Android app settings, allow notifications and set battery usage to unrestricted / allow background activity if your phone offers those controls.
6. Ask the mess person to send a test message containing exactly `Keshavtiffin` to the group while the phone is locked. Confirm the voice announcement starts.
7. Tap STOP ALARM in its notification to stop it manually.

## If you want a release APK
In Android Studio choose **Build > Generate Signed Bundle / APK > APK**, create and safely store a signing key, then finish the wizard. Keep the key secure because future updates should use the same signing key.

## Troubleshooting
- No trigger: check notification access, group notifications, exact message text, and whether WhatsApp's notification shows `Keshavtiffin` as the message body.
- No speech: check media volume, Text-to-Speech output, and install/update an English (India) voice in Android settings.
- Repeated notifications: WhatsApp may repost a notification; test before relying on it. This starter does not include duplicate suppression.
