package com.example.hotspotguard

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.telephony.TelephonyCallback
import android.telephony.TelephonyDisplayInfo
import android.telephony.TelephonyManager

/**
 * Foreground service that watches the mobile network generation.
 * When the phone was on 5G and falls to 4G/3G/2G (and stays there for a few seconds),
 * it asks HotspotAccessibilityService to switch the hotspot off.
 */
class NetworkMonitorService : Service() {

    private lateinit var tm: TelephonyManager
    private val handler = Handler(Looper.getMainLooper())
    private var callback: DisplayCallback? = null

    private var wasOn5G = false
    private var pendingLabel: String? = null

    private val dropRunnable = Runnable {
        val label = pendingLabel ?: return@Runnable
        pendingLabel = null
        wasOn5G = false
        onDroppedFrom5G(label)
    }

    private inner class DisplayCallback : TelephonyCallback(),
        TelephonyCallback.DisplayInfoListener {
        override fun onDisplayInfoChanged(telephonyDisplayInfo: TelephonyDisplayInfo) {
            evaluate(telephonyDisplayInfo)
        }
    }

    override fun onCreate() {
        super.onCreate()
        createChannels()
        startForegroundCompat()

        if (checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            stopSelf()
            return
        }
        tm = getSystemService(TelephonyManager::class.java)
        callback = DisplayCallback().also { tm.registerTelephonyCallback(mainExecutor, it) }
    }

    private fun evaluate(info: TelephonyDisplayInfo) {
        val is5G = info.overrideNetworkType == TelephonyDisplayInfo.OVERRIDE_NETWORK_TYPE_NR_NSA ||
            info.overrideNetworkType == TelephonyDisplayInfo.OVERRIDE_NETWORK_TYPE_NR_ADVANCED ||
            info.networkType == TelephonyManager.NETWORK_TYPE_NR

        if (is5G) {
            wasOn5G = true
            // Came back to 5G before the debounce finished -> cancel
            handler.removeCallbacks(dropRunnable)
            pendingLabel = null
            return
        }

        val label = generationLabel(info.networkType) ?: return // unknown / no service -> ignore
        if (wasOn5G) {
            pendingLabel = label
            handler.removeCallbacks(dropRunnable)
            handler.postDelayed(dropRunnable, Prefs.DEBOUNCE_SECONDS * 1000)
        }
    }

    private fun generationLabel(type: Int): String? = when (type) {
        TelephonyManager.NETWORK_TYPE_LTE,
        TelephonyManager.NETWORK_TYPE_IWLAN -> "4G"

        TelephonyManager.NETWORK_TYPE_UMTS,
        TelephonyManager.NETWORK_TYPE_EVDO_0,
        TelephonyManager.NETWORK_TYPE_EVDO_A,
        TelephonyManager.NETWORK_TYPE_EVDO_B,
        TelephonyManager.NETWORK_TYPE_HSDPA,
        TelephonyManager.NETWORK_TYPE_HSUPA,
        TelephonyManager.NETWORK_TYPE_HSPA,
        TelephonyManager.NETWORK_TYPE_HSPAP,
        TelephonyManager.NETWORK_TYPE_EHRPD,
        TelephonyManager.NETWORK_TYPE_TD_SCDMA -> "3G"

        TelephonyManager.NETWORK_TYPE_GPRS,
        TelephonyManager.NETWORK_TYPE_EDGE,
        TelephonyManager.NETWORK_TYPE_CDMA,
        TelephonyManager.NETWORK_TYPE_1xRTT,
        TelephonyManager.NETWORK_TYPE_IDEN,
        TelephonyManager.NETWORK_TYPE_GSM -> "2G"

        else -> null
    }

    private fun onDroppedFrom5G(newGen: String) {
        val a11y = HotspotAccessibilityService.instance
        if (a11y != null) {
            a11y.turnOffHotspot(newGen)
        } else {
            notifyAlert(
                "Network switched to $newGen",
                "5G is no more. Enable HotspotGuard in Accessibility settings so it can turn off hotspot automatically."
            )
        }
    }

    private fun createChannels() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_STATUS, "Monitoring status", NotificationManager.IMPORTANCE_LOW)
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_ALERT, "Hotspot alerts", NotificationManager.IMPORTANCE_HIGH)
        )
    }

    private fun startForegroundCompat() {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CH_STATUS)
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentTitle("HotspotGuard is watching your network")
            .setContentText("Hotspot will turn off if 5G drops to 4G/3G/2G")
            .setContentIntent(open)
            .setOngoing(true)
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
    }

    private fun notifyAlert(title: String, text: String) {
        val n = Notification.Builder(this, CH_ALERT)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setAutoCancel(true)
            .build()
        getSystemService(NotificationManager::class.java).notify(2, n)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        handler.removeCallbacks(dropRunnable)
        callback?.let { runCatching { tm.unregisterTelephonyCallback(it) } }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        private const val CH_STATUS = "status"
        private const val CH_ALERT = "alert"
    }
}
