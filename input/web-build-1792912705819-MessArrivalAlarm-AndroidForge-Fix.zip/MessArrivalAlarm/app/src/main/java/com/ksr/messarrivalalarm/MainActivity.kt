package com.ksr.messarrivalalarm

import android.Manifest
import android.app.Activity
import android.app.NotificationManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), dp(32), dp(24), dp(24))
        }

        root.addView(TextView(this).apply {
            text = "Mess Arrival Alarm"
            textSize = 26f
            gravity = Gravity.CENTER
        }, matchWidth())

        root.addView(TextView(this).apply {
            text = "\nWhen a WhatsApp notification is exactly “Keshavtiffin”, the app speaks:\n\n“Khana aane wala hai! Please ready raho aur patience rakho. Thank you!”\n\nThe voice alarm stops when you tap STOP or automatically after 60 seconds."
            textSize = 16f
        }, matchWidth())

        root.addView(button("1. Allow notification permission (Android 13+)") {
            if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 11)
            } else {
                openNotificationAccess()
            }
        })

        root.addView(button("2. Enable WhatsApp notification access") { openNotificationAccess() })
        root.addView(button("3. Open app notification settings") {
            val intent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                .putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
            startActivity(intent)
        })
        root.addView(button("STOP ALARM") {
            stopService(Intent(this, AlarmService::class.java))
        })
        root.addView(TextView(this).apply {
            text = "\nSetup: enable WhatsApp group notifications too. If Android asks to exempt this app from battery optimization, allow background operation for better reliability."
            textSize = 13f
        }, matchWidth())

        setContentView(root)
    }

    private fun matchWidth() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = dp(12) }

    private fun button(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setOnClickListener { action() }
        layoutParams = matchWidth()
    }

    private fun openNotificationAccess() {
        startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
    }
}
