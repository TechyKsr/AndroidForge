package com.ksr.messarrivalalarm

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.tts.TextToSpeech
import java.util.Locale

class AlarmService : Service(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var pendingText: String? = null
    private var audioUri: String? = null
    private var audioMode: String = AlarmPrefs.MODE_TTS
    private var durationMs = 60_000L
    private var intervalMs = 8_000L
    private var ready = false
    private var mediaPlayer: MediaPlayer? = null
    private val handler = Handler(Looper.getMainLooper())
    private val autoStop = Runnable { stopAlarm() }
    private val repeatAnnouncement = object : Runnable {
        override fun run() {
            if (pendingText == null) return
            playCurrentAlarm()
            handler.postDelayed(this, intervalMs)
        }
    }

    override fun onCreate() {
        super.onCreate()
        createChannel()
        tts = TextToSpeech(this, this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopAlarm()
            return START_NOT_STICKY
        }
        if (intent?.action == ACTION_START) {
            pendingText = intent.getStringExtra(EXTRA_ANNOUNCEMENT) ?: DEFAULT_ANNOUNCEMENT
            durationMs = intent.getLongExtra(EXTRA_DURATION_MS, 60_000L).coerceIn(10_000L, 600_000L)
            intervalMs = intent.getLongExtra(EXTRA_INTERVAL_MS, 8_000L).coerceIn(3_000L, 60_000L)
            audioUri = intent.getStringExtra(EXTRA_AUDIO_URI)
            audioMode = intent.getStringExtra(EXTRA_AUDIO_MODE) ?: AlarmPrefs.MODE_TTS
            startForeground(NOTIFICATION_ID, buildNotification())
            handler.removeCallbacks(autoStop)
            handler.removeCallbacks(repeatAnnouncement)
            handler.postDelayed(autoStop, durationMs)
            playCurrentAlarm()
            handler.postDelayed(repeatAnnouncement, intervalMs)
        }
        return START_NOT_STICKY
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            ready = true
            val result = tts?.setLanguage(Locale("en", "IN"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) tts?.setLanguage(Locale.US)
        }
    }

    private fun playCurrentAlarm() {
        if (pendingText == null) return
        if (audioMode == AlarmPrefs.MODE_AUDIO && !audioUri.isNullOrBlank()) {
            playAudioFile()
        } else if (ready) {
            tts?.stop()
            tts?.speak(pendingText, TextToSpeech.QUEUE_FLUSH, null, "mess_arrival_announcement")
        }
    }

    private fun playAudioFile() {
        try {
            mediaPlayer?.setOnCompletionListener(null)
            mediaPlayer?.release()
            mediaPlayer = MediaPlayer().apply {
                setDataSource(this@AlarmService, Uri.parse(audioUri))
                setOnPreparedListener { it.start() }
                setOnCompletionListener { player -> player.release(); if (mediaPlayer === player) mediaPlayer = null }
                setOnErrorListener { player, _, _ -> player.release(); if (mediaPlayer === player) mediaPlayer = null; true }
                prepareAsync()
            }
        } catch (_: Exception) {
            audioMode = AlarmPrefs.MODE_TTS
            if (ready) tts?.speak(pendingText, TextToSpeech.QUEUE_FLUSH, null, "mess_arrival_announcement")
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Food arrival alarm", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Shows when the mess food arrival alarm is active"
                setSound(null, null)
                enableVibration(false)
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val stopIntent = Intent(this, AlarmService::class.java).apply { action = ACTION_STOP }
        val stopPending = PendingIntent.getService(this, 1, stopIntent, PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0))
        val openIntent = PendingIntent.getActivity(this, 2, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0))
        val iconChoice = AlarmPrefs.prefs(this).getInt(AlarmPrefs.KEY_ICON, 0)
        val smallIcon = when (iconChoice) { 1 -> R.drawable.ic_alarm; 2 -> R.drawable.ic_bell; else -> R.drawable.ic_food }
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) Notification.Builder(this, CHANNEL_ID) else Notification.Builder(this)
        return builder.setSmallIcon(smallIcon)
            .setContentTitle("Food is arriving!")
            .setContentText("Khana aane wala hai — tap STOP to silence.")
            .setContentIntent(openIntent)
            .setCategory(Notification.CATEGORY_ALARM)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_media_pause, "STOP ALARM", stopPending)
            .build()
    }

    private fun stopAlarm() {
        handler.removeCallbacks(autoStop)
        handler.removeCallbacks(repeatAnnouncement)
        tts?.stop()
        try { mediaPlayer?.setOnCompletionListener(null); mediaPlayer?.release() } catch (_: Exception) { }
        mediaPlayer = null
        pendingText = null
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) stopForeground(STOP_FOREGROUND_REMOVE) else {
            @Suppress("DEPRECATION")
            stopForeground(true)
        }
        stopSelf()
    }

    override fun onDestroy() {
        handler.removeCallbacks(autoStop)
        handler.removeCallbacks(repeatAnnouncement)
        tts?.stop()
        tts?.shutdown()
        try { mediaPlayer?.release() } catch (_: Exception) { }
        mediaPlayer = null
        tts = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_START = "com.ksr.messarrivalalarm.START"
        const val ACTION_STOP = "com.ksr.messarrivalalarm.STOP"
        const val EXTRA_ANNOUNCEMENT = "announcement"
        const val EXTRA_DURATION_MS = "duration_ms"
        const val EXTRA_INTERVAL_MS = "interval_ms"
        const val EXTRA_AUDIO_URI = "audio_uri"
        const val EXTRA_AUDIO_MODE = "audio_mode"
        private const val CHANNEL_ID = "food_arrival_alarm"
        private const val NOTIFICATION_ID = 4107
        private const val DEFAULT_ANNOUNCEMENT = "Khana aane wala hai! Please ready raho aur patience rakho. Thank you!"
    }
}
