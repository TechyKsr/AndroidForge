package com.ksr.messarrivalalarm

import android.app.Notification
import android.content.Intent
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.os.Build

class MessNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val pkg = sbn.packageName
        if (pkg != "com.whatsapp" && pkg != "com.whatsapp.w4b") return
        val extras = sbn.notification.extras ?: return
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.trim().orEmpty()
        val bigText = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()?.trim().orEmpty()
        val prefs = AlarmPrefs.prefs(this)
        val triggerText = prefs.getString(AlarmPrefs.KEY_TRIGGER_TEXT, DEFAULT_TRIGGER_TEXT)?.trim().orEmpty()
        if (triggerText.isEmpty()) return
        if (!listOf(text, bigText).any { it.equals(triggerText, ignoreCase = true) }) return

        val intent = Intent(this, AlarmService::class.java).apply {
            action = AlarmService.ACTION_START
            putExtra(AlarmService.EXTRA_ANNOUNCEMENT, prefs.getString(AlarmPrefs.KEY_ANNOUNCEMENT, DEFAULT_ANNOUNCEMENT) ?: DEFAULT_ANNOUNCEMENT)
            putExtra(AlarmService.EXTRA_DURATION_MS, prefs.getInt(AlarmPrefs.KEY_DURATION, 60) * 1000L)
            putExtra(AlarmService.EXTRA_INTERVAL_MS, prefs.getInt(AlarmPrefs.KEY_INTERVAL, 8) * 1000L)
            putExtra(AlarmService.EXTRA_AUDIO_URI, prefs.getString(AlarmPrefs.KEY_AUDIO_URI, null))
            putExtra(AlarmService.EXTRA_AUDIO_MODE, prefs.getString(AlarmPrefs.KEY_AUDIO_MODE, AlarmPrefs.MODE_TTS) ?: AlarmPrefs.MODE_TTS)
        }
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
        } catch (_: Exception) { }
    }

    companion object {
        private const val DEFAULT_TRIGGER_TEXT = "Keshavtiffin"
        private const val DEFAULT_ANNOUNCEMENT = "Khana aane wala hai! Please ready raho aur patience rakho. Thank you!"
    }
}
