# HotspotGuard

5G se 4G/3G/2G switch hote hi hotspot automatically OFF + popup.

## Build
1. Android Studio (Koala ya naya) me `HotspotGuard` folder open karo, Gradle sync hone do.
2. Phone USB se connect karo (USB debugging ON) -> Run.

## Phone me setup (ek baar)
1. App kholo -> **Grant permissions**.
2. **Enable Accessibility service** -> HotspotGuard -> ON.
   - Android 13+ pe sideload app ke liye grayed-out ho to: **App info** button -> top-right 3 dots -> *Allow restricted settings*, phir dobara Accessibility me ON karo.
3. **Start monitoring**.
4. Pehle **Test: turn hotspot off now** se check karo ki tumhare phone pe hotspot toggle sahi ban raha hai (hotspot ON rakh ke test karo).
5. Battery settings me app ko "Unrestricted" kar do, warna kuch phones service kill kar dete hain.

## Kaise kaam karta hai
- `NetworkMonitorService` (foreground service) TelephonyCallback se network type dekhta hai.
- 5G -> non-5G hone par 5 second wait (flicker se bachne ke liye, `Prefs.DEBOUNCE_SECONDS`), phir hotspot band karta hai.
- Android normal apps ko hotspot off karne nahi deta, isliye `HotspotAccessibilityService` Settings ka Hotspot screen khol ke toggle tap karta hai, back aata hai, aur popup dikhata hai.

## Limits
- Brand-wise Settings UI alag hai (English UI assumed; keywords `HotspotAccessibilityService.KEYWORDS` me hain).
- Screen lock hone par Settings tap nahi ho sakta.
- Ye code abhi tumhare phone pe test nahi hua; pehli run me thoda tweak lag sakta hai.
