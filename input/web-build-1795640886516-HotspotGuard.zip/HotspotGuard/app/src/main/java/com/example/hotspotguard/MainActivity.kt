package com.example.hotspotguard

import android.Manifest
import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var toggleBtn: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        root.addView(TextView(this).apply {
            text = "HotspotGuard"
            textSize = 26f
            setTypeface(null, Typeface.BOLD)
        })
        root.addView(TextView(this).apply {
            text = "Turns your hotspot off automatically when your mobile network drops from 5G to 4G / 3G / 2G."
            setPadding(0, pad / 2, 0, pad)
        })

        status = TextView(this).apply { textSize = 16f; setPadding(0, 0, 0, pad) }
        root.addView(status)

        root.addView(button("1. Grant permissions") { requestPerms() })
        root.addView(button("2. Enable Accessibility service") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            Toast.makeText(this, "Open HotspotGuard and turn it ON", Toast.LENGTH_LONG).show()
        })
        toggleBtn = button("3. Start monitoring") { toggleMonitoring() }
        root.addView(toggleBtn)
        root.addView(button("Test: turn hotspot off now") { testNow() })
        root.addView(button("App info (Allow restricted settings)") {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                    .setData(android.net.Uri.parse("package:$packageName"))
            )
        })

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun button(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        gravity = Gravity.CENTER
        setOnClickListener { onClick() }
    }

    private fun hasPhonePerm() =
        checkSelfPermission(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED

    private fun hasNotifPerm() =
        Build.VERSION.SDK_INT < 33 ||
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    private fun a11yEnabled(): Boolean {
        val flat = ComponentName(this, HotspotAccessibilityService::class.java).flattenToString()
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
        return enabled?.split(':')?.any { it.equals(flat, ignoreCase = true) } == true
    }

    private fun refresh() {
        val on = Prefs.isEnabled(this)
        status.text = buildString {
            appendLine(if (hasPhonePerm()) "✅ Phone state permission" else "❌ Phone state permission")
            appendLine(if (hasNotifPerm()) "✅ Notification permission" else "❌ Notification permission")
            appendLine(if (a11yEnabled()) "✅ Accessibility service ON" else "❌ Accessibility service OFF")
            append(if (on) "✅ Monitoring is running" else "⏸ Monitoring is stopped")
        }
        toggleBtn.text = if (on) "3. Stop monitoring" else "3. Start monitoring"
    }

    private fun requestPerms() {
        val perms = mutableListOf(Manifest.permission.READ_PHONE_STATE)
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        requestPermissions(perms.toTypedArray(), 100)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refresh()
    }

    private fun toggleMonitoring() {
        if (Prefs.isEnabled(this)) {
            Prefs.setEnabled(this, false)
            stopService(Intent(this, NetworkMonitorService::class.java))
        } else {
            if (!hasPhonePerm()) {
                Toast.makeText(this, "Grant phone permission first", Toast.LENGTH_SHORT).show()
                return
            }
            Prefs.setEnabled(this, true)
            startForegroundService(Intent(this, NetworkMonitorService::class.java))
        }
        refresh()
    }

    private fun testNow() {
        val s = HotspotAccessibilityService.instance
        if (s == null) {
            Toast.makeText(this, "Enable the Accessibility service first", Toast.LENGTH_LONG).show()
        } else {
            s.turnOffHotspot("4G")
        }
    }
}
