# QUESTS — AndroidForge starter project

A premium dark, date-based personal timeline planner packaged as a web app.

## Included
- Vertical date timeline (past 7 days through next 30 days, plus dates containing tasks)
- Add/edit/delete tasks on any date
- Planned, pending, completed and missed statuses
- Task notes, optional time and priority
- Attach an image to a task
- Custom app background image
- Local persistence and JSON backup/restore
- Google Calendar two-way sync scaffold (OAuth + Calendar API)
- PWA manifest and service worker

## Build with AndroidForge
1. Extract this ZIP.
2. Upload `index.html`, `manifest.webmanifest`, and `sw.js` to the AndroidForge web compiler.
3. Configure the app name as **QUESTS** and package ID as `app.quests.timeline`.
4. Use a WebView/PWA wrapper that loads the bundled `index.html`.
5. Build and test the APK on your Android phone.

## Google Calendar setup required
Calendar sync is not active until you configure your own Google OAuth client:
1. Create a project in Google Cloud Console.
2. Enable **Google Calendar API**.
3. Configure the OAuth consent screen and add your Google account as a test user if the app is in testing.
4. Create an OAuth **Web application** client ID.
5. Add the app's hosted HTTPS origin (or the wrapper's supported origin) to Authorized JavaScript origins.
6. Paste the Client ID in QUESTS → Settings → Google Calendar, then connect.

The app requests `https://www.googleapis.com/auth/calendar.events`.
- QUESTS-created tasks are written to the primary Google Calendar.
- Calendar events are imported into QUESTS.
- Matching app-created events are linked using a private `questsTaskId` property.
- Images remain local; they are not uploaded to Calendar.

## Important implementation notes
- This is a source starter, not a signed APK.
- Google OAuth may require a hosted HTTPS origin and a properly configured OAuth client. A generic WebView origin may not be accepted by Google's OAuth flow; use AndroidForge's supported hosted/PWA flow or implement native Google Sign-In for a production Android release.
- Calendar sync currently runs when you press **Sync now** or immediately after connecting. It is not a background continuous sync.
- Tasks and image attachments are stored locally on the device/browser profile. Export a backup before clearing app data.
- Test two-way edits, deletions, recurring events, all-day events, and timezone behavior before relying on it for important scheduling.


## App icon — exact image supplied by the user
The launcher/PWA icon assets in this package are cropped directly from the exact original image you uploaded (not the subsequently generated alternative).
- `icon.png`: square master icon
- `icons/icon-192.png` and `icons/icon-512.png`: PWA icons
- `android-res/`: Android launcher resource overlays at common densities, plus adaptive icon XML

When building in AndroidForge, select `icon.png` (or `icons/icon-512.png`) as the app icon if its compiler has an app-icon field. If AndroidForge supports Android resource overlays, use the contents of `android-res/`. Confirm the launcher icon in the final APK preview/build settings before compiling; a WebView page favicon alone does not change the installed Android launcher icon.
