package com.karan.idlesaver

import android.accessibilityservice.AccessibilityService
import android.app.KeyguardManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.SurfaceTexture
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.view.Gravity
import android.view.MotionEvent
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.FrameLayout
import androidx.core.content.ContextCompat
import android.view.WindowManager.LayoutParams as WLP

/**
 * The brain of the app.
 *
 * Why an AccessibilityService?
 *  - A normal app cannot see touches that happen in OTHER apps. An accessibility service can:
 *      (a) it receives accessibility events (click, scroll, typing, window change...)
 *      (b) it may add a 1x1 invisible overlay window with FLAG_WATCH_OUTSIDE_TOUCH, which gets an
 *          ACTION_OUTSIDE event for every touch anywhere else on the screen.
 *  - It may draw an overlay (TYPE_ACCESSIBILITY_OVERLAY) WITHOUT the "draw over other apps" permission.
 *  - It may lock the screen (GLOBAL_ACTION_LOCK_SCREEN, Android 9+).
 *
 * Flow:
 *   screen on -> idle timer (60 s) -> [conditions OK?] -> full-screen video overlay
 *   -> video ends (min 10 s, max 2 min) -> lock screen -> display off.
 *   Any touch on the overlay dismisses it and restarts the timer.
 */
class IdleAccessibilityService : AccessibilityService() {

    companion object {
        /** Lets MainActivity trigger a test run. */
        @Volatile
        var instance: IdleAccessibilityService? = null

        /** If the idle time is over but conditions are not met (music playing...), look again after this. */
        private const val RECHECK_MS = 5_000L
    }

    private val handler = Handler(Looper.getMainLooper())

    private lateinit var wm: WindowManager
    private lateinit var audio: AudioManager
    private lateinit var power: PowerManager
    private lateinit var keyguard: KeyguardManager

    private var touchSensor: View? = null
    private var saverRoot: FrameLayout? = null
    private var player: MediaPlayer? = null
    private var surface: Surface? = null

    /** Package of the last app window we saw (used only for the "home screen only" option). */
    private var foregroundPkg: String? = null

    private val idleRunnable = Runnable { onIdleTimeout() }
    private val endRunnable = Runnable { endSaver(lock = true) }

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                Intent.ACTION_SCREEN_OFF -> {
                    cancelIdle()
                    dismissSaver()
                }
                Intent.ACTION_SCREEN_ON, Intent.ACTION_USER_PRESENT -> scheduleIdle()
            }
        }
    }

    // ---------------------------------------------------------------- lifecycle

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        audio = getSystemService(AUDIO_SERVICE) as AudioManager
        power = getSystemService(POWER_SERVICE) as PowerManager
        keyguard = getSystemService(KEYGUARD_SERVICE) as KeyguardManager

        addTouchSensor()

        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_USER_PRESENT)
        }
        ContextCompat.registerReceiver(this, screenReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)

        if (power.isInteractive) scheduleIdle()
    }

    override fun onInterrupt() {
        // Nothing to interrupt: we give no spoken/haptic feedback.
    }

    override fun onDestroy() {
        instance = null
        cancelIdle()
        if (::wm.isInitialized) {
            dismissSaver()
            touchSensor?.let { runCatching { wm.removeView(it) } }
            touchSensor = null
        }
        runCatching { unregisterReceiver(screenReceiver) }
        super.onDestroy()
    }

    // ---------------------------------------------------------------- detecting user activity

    /**
     * Invisible 1x1 window. Because of FLAG_WATCH_OUTSIDE_TOUCH it is told (ACTION_OUTSIDE)
     * whenever the user touches anything else. We never receive the coordinates, only "a touch happened".
     */
    private fun addTouchSensor() {
        val v = View(this)
        v.setOnTouchListener { _, e ->
            if (e.actionMasked == MotionEvent.ACTION_OUTSIDE) onUserActivity()
            false
        }
        val lp = WLP(
            1, 1,
            WLP.TYPE_ACCESSIBILITY_OVERLAY,
            WLP.FLAG_NOT_FOCUSABLE or WLP.FLAG_NOT_TOUCH_MODAL or WLP.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        wm.addView(v, lp)
        touchSensor = v
    }

    /** Second source of "user is active": accessibility events from other apps. */
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event ?: return
        val pkg = event.packageName?.toString()
        if (pkg == packageName) return // our own overlay must never count as user activity

        when (event.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> {
                if (pkg != null && pkg != "com.android.systemui") foregroundPkg = pkg
                onUserActivity()
            }
            AccessibilityEvent.TYPE_VIEW_CLICKED,
            AccessibilityEvent.TYPE_VIEW_LONG_CLICKED,
            AccessibilityEvent.TYPE_VIEW_SCROLLED,
            AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED,
            AccessibilityEvent.TYPE_VIEW_SELECTED,
            AccessibilityEvent.TYPE_TOUCH_INTERACTION_START,
            AccessibilityEvent.TYPE_TOUCH_INTERACTION_END -> onUserActivity()
        }
    }

    private fun onUserActivity() {
        if (saverRoot != null) return // while the saver is up, only a touch ON the saver counts
        scheduleIdle()
    }

    // ---------------------------------------------------------------- idle timer

    private fun scheduleIdle(delayMs: Long = Prefs.IDLE_MS) {
        handler.removeCallbacks(idleRunnable)
        if (saverRoot == null) handler.postDelayed(idleRunnable, delayMs)
    }

    private fun cancelIdle() = handler.removeCallbacks(idleRunnable)

    private fun onIdleTimeout() {
        if (!power.isInteractive) return
        if (canShowSaver()) showSaver() else scheduleIdle(RECHECK_MS)
    }

    /** All the "is it really safe/appropriate to start the saver?" checks live here. */
    private fun canShowSaver(): Boolean {
        if (!Prefs.isEnabled(this)) return false
        if (Prefs.getVideos(this).isEmpty()) return false
        if (!power.isInteractive) return false
        if (keyguard.isKeyguardLocked) return false              // lock screen is showing
        if (audio.isMusicActive) return false                    // something is playing audio/video
        if (audio.mode != AudioManager.MODE_NORMAL) return false // phone call / VoIP call

        if (Prefs.isStrictHomeOnly(this)) {
            val home = homePackage()
            val fg = foregroundPkg
            if (home != null && fg != null && fg != home) return false // some app is open
        }
        return true
    }

    private fun homePackage(): String? {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        val pkg = packageManager.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY)
            ?.activityInfo?.packageName
        return if (pkg == "android") null else pkg // "android" = chooser dialog, no default launcher
    }

    // ---------------------------------------------------------------- the saver overlay

    /** Called by the "Run saver now" button. Skips the idle checks. */
    fun startSaverForTest() {
        handler.post { showSaver() }
    }

    private fun showSaver() {
        if (saverRoot != null) return
        val videos = Prefs.getVideos(this)
        if (videos.isEmpty()) return
        val uri = Uri.parse(videos.random())

        val root = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            setOnTouchListener { _, e ->
                if (e.actionMasked == MotionEvent.ACTION_DOWN) endSaver(lock = false)
                true // consume everything: the touch must not reach the app below
            }
        }

        val tv = TextureView(this)
        root.addView(
            tv,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT,
                Gravity.CENTER
            )
        )
        tv.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(st: SurfaceTexture, width: Int, height: Int) {
                startPlayback(uri, st, tv)
            }
            override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, width: Int, height: Int) {}
            override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean = true
            override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
        }

        val lp = WLP(
            WLP.MATCH_PARENT, WLP.MATCH_PARENT,
            WLP.TYPE_ACCESSIBILITY_OVERLAY,
            WLP.FLAG_KEEP_SCREEN_ON or      // do NOT let the system timeout kill the display mid-video
                WLP.FLAG_NOT_FOCUSABLE or
                WLP.FLAG_LAYOUT_IN_SCREEN or
                WLP.FLAG_LAYOUT_NO_LIMITS or
                WLP.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.OPAQUE
        ).apply {
            layoutInDisplayCutoutMode = WLP.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }

        cancelIdle()
        wm.addView(root, lp)
        saverRoot = root
    }

    private fun startPlayback(uri: Uri, st: SurfaceTexture, tv: TextureView) {
        val mp = MediaPlayer()
        player = mp
        try {
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MOVIE)
                    .build()
            )
            mp.setDataSource(applicationContext, uri)
            val s = Surface(st)
            surface = s
            mp.setSurface(s)
            if (!Prefs.isSoundOn(this)) mp.setVolume(0f, 0f)

            mp.setOnVideoSizeChangedListener { _, w, h -> fitVideo(tv, w, h) }

            mp.setOnPreparedListener { p ->
                val d = p.duration.toLong()
                // Shorter than the minimum? loop it so it still plays >= MIN_PLAY_MS.
                p.isLooping = d in 1 until Prefs.MIN_PLAY_MS
                // Planned end: the video's own length, but never < MIN and never > MAX.
                val stopAfter = d.coerceIn(Prefs.MIN_PLAY_MS, Prefs.MAX_PLAY_MS) + 300
                handler.removeCallbacks(endRunnable)
                handler.postDelayed(endRunnable, stopAfter)
                p.start()
            }
            // Natural end of a (non-looping) video that is >= MIN long.
            mp.setOnCompletionListener { endSaver(lock = true) }
            // Unreadable / deleted / unsupported file: just close and try again later.
            mp.setOnErrorListener { _, _, _ -> endSaver(lock = false); true }

            mp.prepareAsync()
        } catch (e: Exception) {
            endSaver(lock = false)
        }
    }

    /** Letterbox: scale the video to fit the screen without cropping or stretching. */
    private fun fitVideo(tv: TextureView, vw: Int, vh: Int) {
        if (vw <= 0 || vh <= 0) return
        val dm = resources.displayMetrics
        val scale = minOf(dm.widthPixels.toFloat() / vw, dm.heightPixels.toFloat() / vh)
        tv.layoutParams = FrameLayout.LayoutParams(
            (vw * scale).toInt(), (vh * scale).toInt(), Gravity.CENTER
        )
    }

    /** Tear everything down. Safe to call at any time, any number of times. */
    private fun dismissSaver() {
        handler.removeCallbacks(endRunnable)
        player?.let { p ->
            p.setOnCompletionListener(null)
            p.setOnErrorListener(null)
            p.setOnPreparedListener(null)
            runCatching { p.stop() }
            runCatching { p.release() }
        }
        player = null
        runCatching { surface?.release() }
        surface = null
        saverRoot?.let { runCatching { wm.removeView(it) } }
        saverRoot = null
    }

    /**
     * lock = true  -> video finished: lock the screen (display turns off).
     * lock = false -> user touched the saver / error: go back to normal and restart the 60 s timer.
     */
    private fun endSaver(lock: Boolean) {
        dismissSaver()
        if (lock) performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
        // If the lock worked, ACTION_SCREEN_OFF cancels this timer right away.
        scheduleIdle()
    }
}
