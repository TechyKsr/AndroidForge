package com.example.hotspotguard

import android.content.Context

object Prefs {
    private const val FILE = "hotspotguard"
    private const val KEY_ENABLED = "enabled"

    /** Seconds the network must stay below 5G before hotspot is turned off.
     *  Avoids false triggers when 5G flickers to 4G for a moment. */
    const val DEBOUNCE_SECONDS = 5L

    fun isEnabled(c: Context): Boolean =
        c.getSharedPreferences(FILE, Context.MODE_PRIVATE).getBoolean(KEY_ENABLED, false)

    fun setEnabled(c: Context, v: Boolean) {
        c.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putBoolean(KEY_ENABLED, v).apply()
    }
}
