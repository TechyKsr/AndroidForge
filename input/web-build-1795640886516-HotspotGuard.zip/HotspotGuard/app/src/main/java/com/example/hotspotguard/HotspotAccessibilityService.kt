package com.example.hotspotguard

import android.accessibilityservice.AccessibilityService
import android.app.AlertDialog
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.ContextThemeWrapper
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Android does not let normal apps switch the hotspot off directly.
 * So this service opens the "Hotspot & tethering" settings screen,
 * taps the hotspot toggle if it is ON, goes back, and shows a popup.
 *
 * NOTE: Settings screens differ between phone brands. If it does not work on your
 * phone, adjust KEYWORDS / findHotspotSwitch() below.
 */
class HotspotAccessibilityService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())

    private var running = false
    private var newGen = ""
    private var navigated = false
    private var clicked = false
    private var lastStepAt = 0L

    private val timeout = Runnable { finish(turnedOff = false) }

    override fun onServiceConnected() {
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onInterrupt() {}

    /** Called by NetworkMonitorService (or the Test button). */
    fun turnOffHotspot(generation: String) {
        if (running) return
        running = true
        newGen = generation
        navigated = false
        clicked = false

        val candidates = listOf(
            Intent("android.settings.TETHER_SETTINGS"),
            Intent(Settings.ACTION_WIRELESS_SETTINGS)
        )
        var started = false
        for (i in candidates) {
            try {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(i)
                started = true
                break
            } catch (_: Exception) {
            }
        }
        if (!started) {
            running = false
            return
        }
        handler.postDelayed(timeout, 12_000)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!running || clicked) return
        val now = System.currentTimeMillis()
        if (now - lastStepAt < 400) return
        lastStepAt = now

        val root = rootInActiveWindow ?: return

        // 1) Look for a hotspot switch on this screen
        val sw = findHotspotSwitch(root)
        if (sw != null) {
            if (sw.isChecked) {
                clickNodeOrParent(sw)
                clicked = true
                handler.postDelayed({ finish(turnedOff = true) }, 900)
            } else {
                // Already off, nothing to do
                clicked = true
                handler.postDelayed({ finish(turnedOff = false) }, 300)
            }
            return
        }

        // 2) Pixel-style: hotspot is a row that opens a sub page with the toggle
        if (!navigated) {
            val row = findNodeWithText(root) { it.isClickable || hasClickableParent(it) }
            if (row != null) {
                navigated = true
                clickNodeOrParent(row)
            }
        }
    }

    // ---------- finding things on screen ----------

    private fun findHotspotSwitch(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val checkables = mutableListOf<AccessibilityNodeInfo>()
        collect(root) { if (it.isCheckable) checkables.add(it) }
        for (c in checkables) {
            if (isHotspotRelated(c)) return c
        }
        return null
    }

    /** Walks up max 3 levels; at the first level that has text, decide if it is about hotspot. */
    private fun isHotspotRelated(node: AccessibilityNodeInfo): Boolean {
        var cur: AccessibilityNodeInfo? = node
        repeat(4) {
            val c = cur ?: return false
            val t = allText(c, 3).lowercase()
            if (t.isNotBlank()) {
                if (KEYWORDS.any { t.contains(it) }) return true
                if (OTHER_TETHER.any { t.contains(it) }) return false
            }
            cur = c.parent
        }
        return false
    }

    private fun findNodeWithText(root: AccessibilityNodeInfo, extra: (AccessibilityNodeInfo) -> Boolean): AccessibilityNodeInfo? {
        var found: AccessibilityNodeInfo? = null
        collect(root) {
            if (found == null) {
                val t = ((it.text ?: "").toString() + " " + (it.contentDescription ?: "")).lowercase()
                if (KEYWORDS.any { k -> t.contains(k) } && extra(it)) found = it
            }
        }
        return found
    }

    private fun collect(n: AccessibilityNodeInfo?, f: (AccessibilityNodeInfo) -> Unit) {
        if (n == null) return
        f(n)
        for (i in 0 until n.childCount) collect(n.getChild(i), f)
    }

    private fun allText(n: AccessibilityNodeInfo?, depth: Int): String {
        if (n == null || depth < 0) return ""
        val sb = StringBuilder()
        n.text?.let { sb.append(it).append(' ') }
        n.contentDescription?.let { sb.append(it).append(' ') }
        for (i in 0 until n.childCount) sb.append(allText(n.getChild(i), depth - 1))
        return sb.toString()
    }

    private fun hasClickableParent(n: AccessibilityNodeInfo): Boolean {
        var p = n.parent
        repeat(4) {
            if (p?.isClickable == true) return true
            p = p?.parent
        }
        return false
    }

    private fun clickNodeOrParent(n: AccessibilityNodeInfo) {
        var cur: AccessibilityNodeInfo? = n
        repeat(5) {
            val c = cur ?: return
            if (c.isClickable && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return
            cur = c.parent
        }
    }

    // ---------- finishing ----------

    private fun finish(turnedOff: Boolean) {
        handler.removeCallbacks(timeout)
        if (!running) return
        running = false

        // close settings screen(s)
        performGlobalAction(GLOBAL_ACTION_BACK)
        if (navigated) {
            handler.postDelayed({ performGlobalAction(GLOBAL_ACTION_BACK) }, 400)
        }
        if (turnedOff) {
            handler.postDelayed({ showPopup() }, 800)
        }
    }

    private fun showPopup() {
        val ctx = ContextThemeWrapper(this, android.R.style.Theme_Material_Light_Dialog_Alert)
        val dialog = AlertDialog.Builder(ctx)
            .setTitle("Hotspot turned off")
            .setMessage(
                "Network has been switched to $newGen. 5G is no more, " +
                    "so to save data / internet, hotspot is turned off."
            )
            .setPositiveButton("OK", null)
            .create()
        dialog.window?.setType(WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY)
        dialog.show()
    }

    companion object {
        @Volatile
        var instance: HotspotAccessibilityService? = null

        private val KEYWORDS = listOf("hotspot", "hot spot", "tethering", "tether")
        private val OTHER_TETHER = listOf("usb", "bluetooth", "ethernet")
    }
}
