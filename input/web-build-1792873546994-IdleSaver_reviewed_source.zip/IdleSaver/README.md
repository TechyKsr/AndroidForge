# Idle Saver

Android app (Kotlin, minSdk 28 / Android 9+). If you do not touch the phone for 60 seconds while the
screen is on and nothing else is active, a video you picked plays full screen for at least 10 seconds,
then the screen is locked and the display turns off.

## Build and run

1. Android Studio: **File > Open** and select the `IdleSaver` folder. Let Gradle sync finish.
   (If Studio offers to upgrade the Android Gradle Plugin, accept.)
2. Connect your phone (USB debugging on) and press **Run**.
3. On the phone open **Idle Saver** and follow the numbered steps on screen:
   1. Turn on the accessibility service.
   2. Pick one or more videos from storage.
   3. Leave "Screen saver enabled" on.
   4. Press **Run saver now** to test.
4. Set **Settings > Display > Screen timeout to 2 minutes or more**. Android's own timeout must be
   longer than 60 s idle + 10 s saver, or the system switches the display off first.

### Android 13+ (sideloaded apps)
If the accessibility switch is greyed out: Settings > Apps > Idle Saver > three dots (top right) >
**Allow restricted settings**, then try again.

## How it works (files)

| File | Job |
|---|---|
| `IdleAccessibilityService.kt` | Detects inactivity, checks conditions, plays the overlay video, locks the screen |
| `MainActivity.kt` | Settings screen, video picker, test button |
| `Prefs.kt` | Saved settings + timing constants (`IDLE_MS`, `MIN_PLAY_MS`, `MAX_PLAY_MS`) |
| `res/xml/accessibility_config.xml` | Declares what the service listens to (no screen content is read) |

Change the timings in `Prefs.kt`.

## Rules the app follows before starting the saver
- Screen is on and not on the lock screen
- No audio/video playing anywhere (`isMusicActive`) and no phone/VoIP call
- Optional switch "home screen only": no other app is in the foreground
- At least one video selected and the saver switched on

Touching the screen during the saver closes it and restarts the 60 s timer.

## Known limits
- The service must be enabled by you once in Accessibility settings (Android does not allow apps to do it themselves).
- Turning the display off is done through the lock-screen action, so the phone also locks.
- Google Play restricts non-accessibility uses of the Accessibility API. Fine for personal use / sideloading.
- Written without access to a device or the Android SDK here, so it has not been compiled or run yet.


## Review changes (2026-10-25)
- Narrowed the accessibility event filter from `typeAllMask` to the specific event types handled by the service. This is a privacy-minimization improvement, not a guarantee that Play Protect will allow installation.
- Source review only: this archive has not been compiled or runtime-tested here.
